export LD_LIBRARY_PATH=../lib
../bin/TACE centerline.jpeg centerline.txt
